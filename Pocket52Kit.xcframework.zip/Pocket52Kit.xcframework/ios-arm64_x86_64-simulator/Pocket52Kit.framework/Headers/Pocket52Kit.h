//
//  Pocket52Kit.h
//  Pocket52Kit
//
//  Created by Jay Patel on 13/08/21.
//

#import <Foundation/Foundation.h>

//! Project version number for Pocket52Kit.
FOUNDATION_EXPORT double Pocket52KitVersionNumber;

//! Project version string for Pocket52Kit.
FOUNDATION_EXPORT const unsigned char Pocket52KitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Pocket52Kit/PublicHeader.h>


